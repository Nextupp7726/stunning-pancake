#Twilio Details

account_sid = 'AC9895d14e4f9493a150a7ce27e3aff5fd'
auth_token = '02f312e79bb1a13c09b0cead8f4cdead'
twilionumber = '+18884572518'
twiliosmsnumber = '+18884922860'

#FC Bot
API_TOKEN = "2028472441:AAHi5mLFnrj_zMkhYP8YOPpcFU523-vP3gY"

#Host URL
callurl = 'https://937f1684c78e.ngrok.io'
twiliosmsurl = 'https://937f1684c78e.ngrok.io/sms'









